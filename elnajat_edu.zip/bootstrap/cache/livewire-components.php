<?php return array (
  'admin.change-password' => 'App\\Http\\Livewire\\Admin\\ChangePassword',
  'admin.login' => 'App\\Http\\Livewire\\Admin\\Login',
  'admin.settings' => 'App\\Http\\Livewire\\Admin\\Settings',
  'department.department' => 'App\\Http\\Livewire\\Department\\Department',
  'school.school' => 'App\\Http\\Livewire\\School\\School',
  'teacher.teacher' => 'App\\Http\\Livewire\\Teacher\\Teacher',
  'user.add-edit' => 'App\\Http\\Livewire\\User\\AddEdit',
  'user.change-password' => 'App\\Http\\Livewire\\User\\ChangePassword',
  'user.login' => 'App\\Http\\Livewire\\User\\Login',
  'user.settings' => 'App\\Http\\Livewire\\User\\Settings',
);