<script>
    var base_url = "{{ env('APP_URL') }}/";
</script>
<script src="{{ asset('assets/vendor/global/global.min.js') }}"></script>
<script src="{{ asset('assets/vendor/bootstrap-select/dist/js/bootstrap-select.min.js') }}"></script>

{{-- <script src="{{ asset('assets/vendor/moment/moment.min.js') }}"></script>
<script src="{{ asset('assets/vendor/bootstrap-daterangepicker/daterangepicker.js') }}"></script>
<script src="{{ asset('assets/vendor/clockpicker/js/bootstrap-clockpicker.min.js') }}"></script>
<script src="{{ asset('assets/vendor/jquery-ascolor/jquery-ascolor.min.js') }}"></script>
<script src="{{ asset('assets/vendor/jquery-asgradient/jquery-asgradient.min.js') }}"></script>
<script src="{{ asset('assets/vendor/jquery-ascolorpicker/js/jquery-ascolorpicker.min.js') }}"></script>
<script src="{{ asset('assets/vendor/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js') }}"></script>
<script src="{{ asset('assets/vendor/pickadate/picker.js') }}"></script>
<script src="{{ asset('assets/vendor/pickadate/picker.time.js') }}"></script>
<script src="{{ asset('assets/vendor/pickadate/picker.date.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/bs-daterange-picker-init.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/clock-picker-init.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/jquery-ascolorpicker.init.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/material-date-picker-init.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/pickadate-init.js') }}"></script> --}}

<script src="{{ asset('assets/vendor/ckeditor/ckeditor.js') }}"></script>
<script src="{{ asset('assets/vendor/jquery-sparkline/jquery.sparkline.min.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/sparkline-init.js') }}"></script>
<script src="{{ asset('assets/vendor/morris/morris.min.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/widgets-script-init.js') }}"></script>
<script src="{{ asset('assets/js/dashboard/dashboard.js') }}"></script>
<script src="{{ asset('assets/vendor/svganimation/vivus.min.js') }}"></script>
<script src="{{ asset('assets/vendor/svganimation/svg.animation.js') }}"></script>
<script src="{{ asset('assets/js/custom.min.js') }}"></script>
<script src="{{ asset('assets/js/dlabnav-init.js') }}"></script>
<script src="{{ asset('assets/js/demo.js') }}"></script>

{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script> --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>


