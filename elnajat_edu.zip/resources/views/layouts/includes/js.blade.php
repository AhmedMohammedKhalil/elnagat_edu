<script>
    var base_url = "{{ env('APP_URL') }}/";
</script>
<script src="{{ asset('assets/vendor/global/global.min.js') }}"></script>
<script src="{{ asset('assets/vendor/bootstrap-select/dist/js/bootstrap-select.min.js') }}"></script>
<script src="{{ asset('assets/vendor/ckeditor/ckeditor.js') }}"></script>
<script src="{{ asset('assets/vendor/jquery-sparkline/jquery.sparkline.min.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/sparkline-init.js') }}"></script>
<script src="{{ asset('assets/vendor/morris/morris.min.js') }}"></script>
<script src="{{ asset('assets/js/plugins-init/widgets-script-init.js') }}"></script>
<script src="{{ asset('assets/js/dashboard/dashboard.js') }}"></script>
<script src="{{ asset('assets/vendor/svganimation/vivus.min.js') }}"></script>
<script src="{{ asset('assets/vendor/svganimation/svg.animation.js') }}"></script>
<script src="{{ asset('assets/js/custom.min.js') }}"></script>
<script src="{{ asset('assets/js/dlabnav-init.js') }}"></script>
<script src="{{ asset('assets/js/demo.js') }}"></script>


