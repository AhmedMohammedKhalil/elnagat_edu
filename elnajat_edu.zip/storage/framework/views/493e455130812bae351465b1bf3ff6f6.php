<script>
    var base_url = "<?php echo e(env('APP_URL')); ?>/";
</script>
<script src="<?php echo e(asset('assets/vendor/global/global.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>



<script src="<?php echo e(asset('assets/vendor/ckeditor/ckeditor.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-sparkline/jquery.sparkline.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/plugins-init/sparkline-init.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/morris/morris.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/plugins-init/widgets-script-init.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/dashboard/dashboard.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/svganimation/vivus.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/svganimation/svg.animation.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/custom.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/dlabnav-init.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/demo.js')); ?>"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>


<?php /**PATH D:\xampp\htdocs\elnajat_edu\resources\views/layouts/includes/js.blade.php ENDPATH**/ ?>