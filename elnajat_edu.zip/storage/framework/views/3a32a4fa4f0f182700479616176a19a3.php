<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">

        <div class="row page-titles mx-0" style="height: 200px">
            <div class="col-sm-12">
                <div class="welcome-text text-center">
                    <h4>المعلمين</h4>
                </div>
            </div>
        </div>

        <div class="row">
            <?php if($departments): ?>
            <div class="col-lg-12">
                <ul class="nav nav-pills mb-3">
                    <li class="nav-item"><a href="#list-view" data-bs-toggle="tab" class="nav-link me-1 show active">عرض المعلمين</a></li>
                    <li class="nav-item"><a href="#add-teacher" data-bs-toggle="tab" class="nav-link">إضافة معلم جديد</a></li>
                </ul>
            </div>
            <div class="col-lg-12">
                <div class="row tab-content">
                    <div id="list-view" class="tab-pane fade active show col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">جميع المعلمين</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example5" class="display text-nowrap text-center" style="min-width: 845px">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>الإسم</th>
                                                <th>القسم</th>
                                                <th>الإعدادات</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $flag = false;
                                                $i = 0;
                                            ?>
                                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php $__currentLoopData = $department->teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $flag = true;
                                                    ?>
                                                    <tr>
                                                        <td><?php echo ++$i; ?></td>
                                                        <td><?php echo e($teacher->name); ?></td>
                                                        <td><?php echo e($department->name); ?></td>

                                                        <td>
                                                            <a href="<?php echo e(route('levels.index',['id' => $teacher->id])); ?>" title="المراحل التعليمية" class="btn btn-xs sharp btn-primary"><i class="fa fa-eye"></i></a>
                                                            <a href="<?php echo e(route('teachers.edit',['id' => $teacher->id])); ?>" title="تعديل" class="btn btn-xs sharp btn-primary"><i class="fa fa-pencil"></i></a>
                                                            <?php if(count($teacher->levels) == 0): ?>
                                                                <form style="display:inline-block" action="<?php echo e(route('teachers.destroy',['id'=>$teacher->id])); ?>" method="post">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('delete'); ?>
                                                                    <button class="btn btn-xs sharp btn-danger" type="submit" title="حذف" >
                                                                        <i class='fa fa-trash'></i>
                                                                    </button>
                                                                </form>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($flag == false): ?>
                                                <tr>
                                                    <td colspan="4">
                                                        <h4 class="text-center">لا يوجد معلمين</h4>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="add-teacher" class="tab-pane fade col-lg-12 row">
                        <div class="col-lg-6 col-sm-12 m-auto">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">أضف معلم جديد</h4>
                                </div>
                                <div class="card-body">
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('teacher.teacher', ['teacherId' => '0','method' => 'add','teacher_id' => '0'])->html();
} elseif ($_instance->childHasBeenRendered('pwXrfKt')) {
    $componentId = $_instance->getRenderedChildComponentId('pwXrfKt');
    $componentTag = $_instance->getRenderedChildComponentTagName('pwXrfKt');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pwXrfKt');
} else {
    $response = \Livewire\Livewire::mount('teacher.teacher', ['teacherId' => '0','method' => 'add','teacher_id' => '0']);
    $html = $response->html();
    $_instance->logRenderedChild('pwXrfKt', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php else: ?>
                <div class="col-12">
                    <h2 class="text-center">لا يوجد أقسام لديك لابد من إضافة قسم واحد على الأقل</h2>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\elnajat_edu\resources\views/teachers/index.blade.php ENDPATH**/ ?>