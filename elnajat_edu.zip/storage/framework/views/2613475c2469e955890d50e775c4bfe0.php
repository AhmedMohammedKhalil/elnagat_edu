<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">

        <div class="row page-titles mx-0" style="height: 200px">
            <div class="col-sm-12">
                <div class="welcome-text text-center">
                    <h4> تقارير الاقسام </h4>
                </div>
            </div>
        </div>

        <div class="row">
            
            <div class="col-lg-12">
                <div class="row tab-content">
                    <div id="add-official" class="col-lg-12 row">
                        <div class="col-lg-6 col-sm-12 m-auto">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title"> تقارير الاقسام </h4>
                                </div>
                                <div class="card-body">
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('report.department-report', [])->html();
} elseif ($_instance->childHasBeenRendered('BSSAZxV')) {
    $componentId = $_instance->getRenderedChildComponentId('BSSAZxV');
    $componentTag = $_instance->getRenderedChildComponentTagName('BSSAZxV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BSSAZxV');
} else {
    $response = \Livewire\Livewire::mount('report.department-report', []);
    $html = $response->html();
    $_instance->logRenderedChild('BSSAZxV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\elnajat_edu\resources\views/reports/departmentreport.blade.php ENDPATH**/ ?>