<div style="">
    <div class="login-form">
        <form wire:submit.prevent='getreport'>
            <?php if(session()->has('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

                <div class="form-group">
                    <label class="school_id">المدرسة</label>
                    <select class="form-control" wire:model.lazy='school_id' id="school_id">
                        <option value="0">اختر المدرسة</option>
                        <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
                            <option value="<?php echo e($school->id); ?>"><?php echo e($school->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['school_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                    <button type="submit" class="btn btn-primary d-block m-auto">تحرير تقرير</button>
        </form>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\elnajat_edu\resources\views/livewire/report/official-school-report.blade.php ENDPATH**/ ?>