<?php $__env->startSection('content'); ?>
    <div><?php echo e($page_name); ?></div>
    <div>
        <?php echo $__env->make('users.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('section'); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\elnajat_edu\resources\views/users/layout.blade.php ENDPATH**/ ?>