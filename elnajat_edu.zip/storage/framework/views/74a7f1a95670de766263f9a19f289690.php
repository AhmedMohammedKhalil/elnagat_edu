<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">

        <div class="row page-titles mx-0" style="height: 200px">
            <div class="col-sm-12">
                <div class="welcome-text text-center">
                    <h4>المراحل التعليمية</h4>
                </div>
            </div>
        </div>

        <div class="row">
            <?php if(auth()->user()->owner): ?>
                <div class="col-lg-12">
                    <ul class="nav nav-pills mb-3">
                        <li class="nav-item"><a href="#list-view" data-bs-toggle="tab" class="nav-link me-1 show active">عرض المراحل التعليمية</a></li>
                        <?php if(count($teacher->levels)<3): ?>
                        <li class="nav-item"><a href="#add-level" data-bs-toggle="tab" class="nav-link">إضافة مرحلة تعليمية جديدة</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="col-lg-12">
                    <div class="row tab-content">
                        <div id="list-view" class="tab-pane fade active show col-lg-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">جميع المراحل التعليمية</h4>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="example5" class="display text-nowrap text-center" style="min-width: 845px">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>المستوى</th>
                                                    <th>اسم المدرس</th>
                                                    <th>الإعدادات</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $teacher->levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td><?php echo e($level->name); ?></td>
                                                        <td><?php echo e($level->teacher->name); ?></td>
                                                        <td>
                                                        <a href="<?php echo e(route('classrooms.index',['id' => $level->id])); ?>" title="الصفوف الدراسية" class="btn btn-xs sharp btn-primary"><i class="fa fa-eye"></i></a>
                                                            <?php if(count($level->classrooms) == 0): ?>
                                                                <form style="display:inline-block" action="<?php echo e(route('levels.destroy',['level_id'=>$level->id,'id'=>$teacher->id])); ?>" method="post">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('delete'); ?>
                                                                    <button class="btn btn-xs sharp btn-danger" type="submit" title="حذف" >
                                                                        <i class='fa fa-trash'></i>
                                                                    </button>
                                                                </form>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(count($teacher->levels) == 0): ?>
                                                    <tr>
                                                        <td colspan="4">
                                                            <h4 class="text-center">لا يوجد مرحلة تعليمية </h4>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="add-level" class="tab-pane fade col-lg-12 row">
                            <div class="col-lg-6 col-sm-12 m-auto">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="card-title">أضف مرحلة دراسية جديدة</h4>
                                    </div>
                                    <div class="card-body">
                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('level.level', ['teacherId' => $teacher->id,'teacher_id' => $teacher->id])->html();
} elseif ($_instance->childHasBeenRendered('5TVYI16')) {
    $componentId = $_instance->getRenderedChildComponentId('5TVYI16');
    $componentTag = $_instance->getRenderedChildComponentTagName('5TVYI16');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5TVYI16');
} else {
    $response = \Livewire\Livewire::mount('level.level', ['teacherId' => $teacher->id,'teacher_id' => $teacher->id]);
    $html = $response->html();
    $_instance->logRenderedChild('5TVYI16', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <?php else: ?>
                <div class="col-12">
                    <h2 class="text-center">لا يوجد  مدرسة لديك لابد من إضافة المدرسة اولاً</h2>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\elnajat_edu\resources\views/levels/index.blade.php ENDPATH**/ ?>