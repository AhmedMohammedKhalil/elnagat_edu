<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">

        <div class="row page-titles mx-0" style="height: 200px">
            <div class="col-sm-12">
                <div class="welcome-text text-center">
                    <h4>فريق التشغيل</h4>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <ul class="nav nav-pills mb-3">
                    <li class="nav-item"><a href="#list-view" data-bs-toggle="tab" class="nav-link me-1 show active">عرض فريق التشغيل</a></li>
                    <li class="nav-item"><a href="#add-official" data-bs-toggle="tab" class="nav-link">إضافة عضو جديد</a></li>
                </ul>
            </div>
            <div class="col-lg-12">
                <div class="row tab-content">
                    <div id="list-view" class="tab-pane fade active show col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">فريق التشغيل</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example5" class="display text-nowrap text-center" style="min-width: 845px">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>الإسم</th>
                                                <th>النوع</th>
                                                <th>البريد الإلكترونى</th>
                                                <th>المدرسة</th>
                                                <th>الإعدادات</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $officials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $official): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($official->name); ?></td>
                                                    <td><?php echo e($official->gender); ?></td>
                                                    <td><?php echo e($official->email); ?></td>
                                                    <td><?php echo e($official->owner?->name); ?></td>


                                                    <td>
                                                        <a href="<?php echo e(route('officials.edit',['id' => $official->id])); ?>" title="تعديل" class="btn btn-xs sharp btn-primary"><i class="fa fa-pencil"></i></a>
                                                        <?php if(!$official->owner): ?>
                                                        <form style="display:inline-block" action="<?php echo e(route('officials.destroy',['id'=>$official->id])); ?>" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('delete'); ?>
                                                            <button class="btn btn-xs sharp btn-danger" type="submit" title="حذف">
                                                                <i class='fa fa-trash'></i>
                                                            </button>
                                                        </form>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(count($officials) == 0): ?>
                                                <tr>
                                                    <td colspan="6">
                                                        <h4 class="text-center">لا يوجد فريق تشغيل</h4>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="add-official" class="tab-pane fade col-lg-12 row">
                        <div class="col-lg-6 col-sm-12 m-auto">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">أضف عضو جديد</h4>
                                </div>
                                <div class="card-body">
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.add-edit', ['userId' => '0','method' => 'addOfficial','user_id' => '0'])->html();
} elseif ($_instance->childHasBeenRendered('0vTq7xv')) {
    $componentId = $_instance->getRenderedChildComponentId('0vTq7xv');
    $componentTag = $_instance->getRenderedChildComponentTagName('0vTq7xv');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0vTq7xv');
} else {
    $response = \Livewire\Livewire::mount('user.add-edit', ['userId' => '0','method' => 'addOfficial','user_id' => '0']);
    $html = $response->html();
    $_instance->logRenderedChild('0vTq7xv', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\elnajat_edu\resources\views/officials/index.blade.php ENDPATH**/ ?>