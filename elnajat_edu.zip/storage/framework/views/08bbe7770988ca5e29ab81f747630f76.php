<div style="">
    <div class="login-form">
        <form wire:submit.prevent='<?php echo e($method); ?>'>
            <?php if(session()->has('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <fieldset>
                <legend>بيانات القسم</legend>
                <div class="form-group">
                    <label for="name">الإسم</label>
                    <input type="text" wire:model.lazy='name' id="name" class="form-control" placeholder="الإسم">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </fieldset>

                <hr>
                <fieldset>
                    <legend>بيانات رئيس القسم</legend>
                <div class="form-group">
                    <label for="username">إسم رئيس القسم</label>
                    <input type="text" wire:model.lazy='username' id="username" class="form-control" placeholder="إسم المدير المساعد">
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="email">البريد الإلكترونى</label>
                    <input type="email" wire:model.lazy='email' id="email" class="form-control" placeholder="البريد الإلكترونى">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label class="gender">النوع</label>
                    <select class="form-control" wire:model.lazy='gender' id="gender">
                        <option value="ذكر" <?php if($gender == 'ذكر'): ?> selected <?php endif; ?>>ذكر</option>
                        <option value="أنثى" <?php if($gender == 'أنثى'): ?> selected <?php endif; ?>>أنثى</option>
                    </select>
                    <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="password">كلمة المرور</label>
                    <input type="password" wire:model.lazy='password' id="password" class="form-control" placeholder="كلمة المرور">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="confirm_password">أعد كلمة المرور</label>
                    <input type="password" wire:model='confirm_password' id="confirm_password" class="form-control" placeholder="أعد كلمة المرور">
                    <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                </fieldset>

                <?php if($method != "add"): ?>
                    <button type="submit" class="btn btn-primary d-block m-auto">حفظ التغييرات</button>
                <?php else: ?>
                    <button type="submit" class="btn btn-primary d-block m-auto">إضافة</button>
                <?php endif; ?>
        </form>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\elnajat_edu\resources\views/livewire/admin/department.blade.php ENDPATH**/ ?>