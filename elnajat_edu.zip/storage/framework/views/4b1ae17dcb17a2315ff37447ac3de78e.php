<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row page-titles mx-0" style="height: 200px">
            <div class="col-sm-12">
                <div class="welcome-text text-center">
                    <h4>تعديل بيانات القسم </h4>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6 col-sm-12 m-auto">
                <div class="card">
                    <div class="card-body">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.department', ['departmentId' => $department_id,'method' => 'edit','department_id' => $department_id])->html();
} elseif ($_instance->childHasBeenRendered('ogNyoF4')) {
    $componentId = $_instance->getRenderedChildComponentId('ogNyoF4');
    $componentTag = $_instance->getRenderedChildComponentTagName('ogNyoF4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ogNyoF4');
} else {
    $response = \Livewire\Livewire::mount('admin.department', ['departmentId' => $department_id,'method' => 'edit','department_id' => $department_id]);
    $html = $response->html();
    $_instance->logRenderedChild('ogNyoF4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\elnajat_edu\resources\views/admin/department_edit.blade.php ENDPATH**/ ?>