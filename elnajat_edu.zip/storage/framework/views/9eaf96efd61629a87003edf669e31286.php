<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">

        <div class="row page-titles mx-0" style="height: 200px">
            <div class="col-sm-12">
                <div class="welcome-text text-center">
                    <h4> تقرير المدرسة </h4>
                </div>
            </div>
        </div>

        <div class="row">
            
            <div class="col-lg-12">
                <div class="row tab-content">
                    <div id="add-official" class="col-lg-12 row">
                        <div class="col-lg-6 col-sm-12 m-auto">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title"> تقرير المدرسة </h4>
                                </div>
                                <div class="card-body">
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('report.official-school-report', [])->html();
} elseif ($_instance->childHasBeenRendered('YpLxZFj')) {
    $componentId = $_instance->getRenderedChildComponentId('YpLxZFj');
    $componentTag = $_instance->getRenderedChildComponentTagName('YpLxZFj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YpLxZFj');
} else {
    $response = \Livewire\Livewire::mount('report.official-school-report', []);
    $html = $response->html();
    $_instance->logRenderedChild('YpLxZFj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\elnajat_edu\resources\views/reports/officialSchoolReport.blade.php ENDPATH**/ ?>