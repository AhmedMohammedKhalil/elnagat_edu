

<div class="footer">
    <div class="copyright">
        <p style="color:#044c71 !important">جميع الحقوق محفوظة للإدارة العامة لمدارس النجاة - الفريق التشغيلى للمدارس © 2024 </p>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\elnajat_edu\resources\views/layouts/includes/footer.blade.php ENDPATH**/ ?>