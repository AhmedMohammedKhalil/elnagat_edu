<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">

        <div class="row page-titles mx-0" style="height: 200px">
            <div class="col-sm-12">
                <div class="welcome-text text-center">
                    <h4>المدارس</h4>
                </div>
            </div>
        </div>
        <div class="row">
                <div class="col-lg-12">
                    <ul class="nav nav-pills mb-3">
                        <li class="nav-item"><a href="#list-view" data-bs-toggle="tab" class="nav-link me-1 show active">عرض المدرسة</a></li>
                        <?php if(!auth()->user()->owner): ?>
                        <li class="nav-item"><a href="#add-school" data-bs-toggle="tab" class="nav-link">إضافة مدرسة جديدة</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="col-lg-12">
                    <div class="row tab-content">
                        <div id="list-view" class="tab-pane fade active show col-lg-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">بيانات المدرسة</h4>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="example5" class="display text-nowrap text-center" style="min-width: 845px">
                                            <thead>
                                                <tr>
                                                    <th>الإسم</th>
                                                    <th>مدير المدرسة</th>
                                                    <th>المدير المساعد</th>
                                                    <th>البريد الإلكترونى</th>
                                                    <th>الإعدادات</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if($school): ?>
                                                    <tr>
                                                        <td><?php echo e($school->name); ?></td>
                                                        <td><?php echo e($school->owner); ?></td>
                                                        <td><?php echo e($school->sub_admin->name); ?></td>
                                                        <td><?php echo e($school->sub_admin->email); ?></td>
                                                        <td>
                                                            <a href="<?php echo e(route('schools.edit',['id' => $school->id])); ?>" title="تعديل" class="btn btn-xs sharp btn-primary"><i class="fa fa-pencil"></i></a>
                                                            <?php if(count($school->departments) == 0): ?>
                                                                <form style="display:inline-block" action="<?php echo e(route('schools.destroy',['id'=>$school->id])); ?>" method="post">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('delete'); ?>
                                                                    <button class="btn btn-xs sharp btn-danger" type="submit" title="حذف" >
                                                                        <i class='fa fa-trash'></i>
                                                                    </button>
                                                                </form>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php else: ?>
                                                    <tr>
                                                        <td colspan="5">
                                                            <h4 class="text-center">لا يوجد مدارس </h4>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php if(!auth()->user()->owner): ?>
                        <div id="add-school" class="tab-pane fade col-lg-12 row">
                            <div class="col-lg-6 col-sm-12 m-auto">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="card-title">أضف مدرسة جديدة</h4>
                                    </div>
                                    <div class="card-body">
                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('school.school', ['schoolId' => '0','method' => 'add','school_id' => '0'])->html();
} elseif ($_instance->childHasBeenRendered('ytWinGq')) {
    $componentId = $_instance->getRenderedChildComponentId('ytWinGq');
    $componentTag = $_instance->getRenderedChildComponentTagName('ytWinGq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ytWinGq');
} else {
    $response = \Livewire\Livewire::mount('school.school', ['schoolId' => '0','method' => 'add','school_id' => '0']);
    $html = $response->html();
    $_instance->logRenderedChild('ytWinGq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\elnajat_edu\resources\views/schools/index.blade.php ENDPATH**/ ?>