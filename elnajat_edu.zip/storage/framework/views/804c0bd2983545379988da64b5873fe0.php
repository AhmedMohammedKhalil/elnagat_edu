<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">

        <div class="row page-titles mx-0" style="height: 200px">
            <div class="col-sm-12">
                <div class="welcome-text text-center">
                    <h4>الأسابيع </h4>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <ul class="nav nav-pills mb-3">
                    <li class="nav-item"><a href="#list-view" data-bs-toggle="tab" class="nav-link me-1 show active">عرض جميع الأسابيع </a></li>
                    <?php if(isset($weeks) && count($weeks) < 13): ?>
                    <li class="nav-item"><a href="#add-week" data-bs-toggle="tab" class="nav-link">إضافة أسبوع جديد</a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="col-lg-12">
                <div class="row tab-content">
                    <div id="list-view" class="tab-pane fade active show col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">فريق التشغيل</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example5" class="display text-nowrap text-center" style="min-width: 845px">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th> الأسبوع</th>
                                                <th>بداية الأسبوع</th>
                                                <th>نهاية الأسبوع</th>
                                                <th>الإعدادات</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $weeks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($week->week_index); ?></td>
                                                    <td><?php echo e($week->start_date); ?></td>
                                                    <td><?php echo e($week->end_date); ?></td>

                                                    <td>
                                                        <?php if(count($week->reviews) == 0): ?>
                                                        <a href="<?php echo e(route('weeks.edit',['id' => $week->id])); ?>" title="تعديل" class="btn btn-xs sharp btn-primary"><i class="fa fa-pencil"></i></a>
                                                        <form style="display:inline-block" action="<?php echo e(route('weeks.destroy',['id'=>$week->id])); ?>" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('delete'); ?>
                                                            <button class="btn btn-xs sharp btn-danger" type="submit" title="حذف">
                                                                <i class='fa fa-trash'></i>
                                                            </button>
                                                        </form>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(count($weeks) == 0): ?>
                                                <tr>
                                                    <td colspan="6">
                                                        <h4 class="text-center">لا يوجد أسابيع</h4>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if(isset($weeks) && count($weeks) < 13): ?>
                    <div id="add-week" class="tab-pane fade col-lg-12 row">
                        <div class="col-lg-6 col-sm-12 m-auto">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">إضافة أسبوع جديد</h4>
                                </div>
                                <div class="card-body">
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('week.week', ['weekId' => '0','method' => 'add','week_id' => '0'])->html();
} elseif ($_instance->childHasBeenRendered('zvmahzW')) {
    $componentId = $_instance->getRenderedChildComponentId('zvmahzW');
    $componentTag = $_instance->getRenderedChildComponentTagName('zvmahzW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('zvmahzW');
} else {
    $response = \Livewire\Livewire::mount('week.week', ['weekId' => '0','method' => 'add','week_id' => '0']);
    $html = $response->html();
    $_instance->logRenderedChild('zvmahzW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\elnajat_edu\resources\views/weeks/index.blade.php ENDPATH**/ ?>