<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">

        <div class="row page-titles mx-0" style="height: 200px">
            <div class="col-sm-12">
                <div class="welcome-text text-center">
                    <h4>المتابعات</h4>
                </div>
            </div>
        </div>

        <div class="row">
            <?php if($flag): ?>
            <div class="col-lg-12">
                <ul class="nav nav-pills mb-3">
                    <li class="nav-item"><a href="#list-view" data-bs-toggle="tab" class="nav-link me-1 show active">عرض المتابعات</a></li>
                    <?php if($count != count($reviews)): ?>
                        <li class="nav-item"><a href="#add-review" data-bs-toggle="tab" class="nav-link">إضافة متابعة جديدة</a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="col-lg-12">
                <div class="row tab-content">
                    <div id="list-view" class="tab-pane fade active show col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">جميع المتابعات</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example5" class="display text-nowrap text-center" style="min-width: 845px">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>اسم المعلم</th>
                                                <th>المرحلة التعليمية</th>
                                                <th>الصف الدراسى</th>
                                                <th>التقييم الإجمالى</th>
                                                <th>الإعدادات</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($review->teacher->name); ?></td>
                                                    <td><?php echo e($review->classroom->level->name); ?></td>
                                                    <td><?php echo e($review->classroom->name); ?></td>
                                                    <td><?php echo e($review->result); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(route('reviews.edit',['id' => $review->id])); ?>" title="تعديل" class="btn btn-xs sharp btn-primary"><i class="fa fa-pencil"></i></a>
                                                        <form style="display:inline-block" action="<?php echo e(route('reviews.destroy',['id'=>$review->id])); ?>" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('delete'); ?>
                                                            <button class="btn btn-xs sharp btn-danger" type="submit" title="حذف" >
                                                                <i class='fa fa-trash'></i>
                                                            </button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$reviews): ?>
                                                <tr>
                                                    <td colspan="6">
                                                        <h4 class="text-center">لا يوجد متابعات</h4>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="add-review" class="tab-pane fade col-lg-12 row">
                        <div class="col-lg-12 col-sm-12 m-auto">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">أضف متابعة جديدة</h4>
                                </div>
                                <div class="card-body">
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('review.review', ['weekId' => $current_week->id,'reviewId' => '0','method' => 'add','week_id' => $current_week->id,'review_id' => '0'])->html();
} elseif ($_instance->childHasBeenRendered('ZDW5ial')) {
    $componentId = $_instance->getRenderedChildComponentId('ZDW5ial');
    $componentTag = $_instance->getRenderedChildComponentTagName('ZDW5ial');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ZDW5ial');
} else {
    $response = \Livewire\Livewire::mount('review.review', ['weekId' => $current_week->id,'reviewId' => '0','method' => 'add','week_id' => $current_week->id,'review_id' => '0']);
    $html = $response->html();
    $_instance->logRenderedChild('ZDW5ial', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php else: ?>
                <div class="col-12">
                    <h2 class="text-center">لا يوجد صفوف دراسية لهذة المدرسة</h2>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\elnajat_edu\resources\views/reviews/index.blade.php ENDPATH**/ ?>