<?php $__env->startPush('css'); ?>
    <style>


        .review .row{
            justify-content: center;
            align-items: center
        }
        /* @media (min-width: 576px){
            .review .col-sm-12 {
                flex: 0 0 auto;
                width: 90.999% !important;
            }
        } */
        @media (min-width: 768px){
            .review .col-lg-7 {
                flex: 0 0 auto;
                width: 55.55556% !important;
            }

            .review .col-lg-3 {
                flex: 0 0 auto;
                width: 22.22223% !important;
            }
        }




    </style>
<?php $__env->stopPush(); ?>

<div style="">
    <div class="login-form">
        <form wire:submit.prevent='<?php echo e($method); ?>'>
            <?php if(session()->has('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-md-6 col-sm-12">
                    <div class="form-group">
                        <label for="date">تاريخ اليوم</label>
                        <input readonly id="date" type="text" class="form-control" value="<?php echo \Carbon\Carbon::parse($date)->translatedFormat("l Y-m-d"); ?>">
                    </div>
                </div>

                <div class="col-md-6 col-sm-12">
                    <div class="form-group">
                        <label for="school">المدرسة</label>
                        <input readonly id="school" type="text" class="form-control" value="<?php echo e($school->name); ?>">
                    </div>
                </div>


                <div class="col-md-6 col-sm-12">
                    <div class="form-group">
                        <label for="department">القسم</label>
                        <input readonly id="department" type="text" class="form-control" value="<?php echo e($department->name); ?>">
                    </div>
                </div>

                

                <div class="col-md-6 col-sm-12">
                    <div class="form-group">
                        <label class="teacher_id"></label>المعلم</label>
                        <select class="form-control" wire:model='teacher_id' id="teacher_id" <?php if($method != 'add'): ?> disabled <?php endif; ?>>
                            <?php if($method == 'add'): ?>
                            <option value="0" selected>اختر المعلم</option>
                            <?php endif; ?>
                            <?php if($teachers): ?>
                            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(count($teacher->levels) > 0): ?>
                                <option value="<?php echo e($teacher->id); ?>" <?php if($teacher_id == $teacher->id): ?> selected <?php endif; ?>><?php echo e($teacher->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <?php $__errorArgs = ['teacher_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6 col-sm-12">
                    <div class="form-group">
                        <label class="level_id"></label>المرحلة التعليمية</label>
                        <select class="form-control" wire:model='level_id' id="level_id" <?php if($method != 'add'): ?> disabled <?php endif; ?>>
                            <?php if($method == 'add'): ?>
                            <option value="0" selected>اختر المرحلة التعليمية</option>
                            <?php endif; ?>
                            <?php if($levels): ?>
                            <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(count($level->classrooms) > 0): ?>
                                <option value="<?php echo e($level->id); ?>" <?php if($level_id == $level->id): ?> selected <?php endif; ?>><?php echo e($level->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <?php $__errorArgs = ['level_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6 col-sm-12">
                    <div class="form-group">
                        <label class="classroom_id"></label>الصف الدراسى</label>
                        <select class="form-control" wire:model='classroom_id' id="classroom_id" <?php if($method != 'add'): ?> disabled <?php endif; ?>>
                            <?php if($method == 'add'): ?>
                            <option value="0" selected>اختر الصف الدراسى</option>
                            <?php endif; ?>

                            <?php if($classrooms): ?>
                            <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($classroom->id); ?>" <?php if($classroom_id == $classroom->id): ?> selected <?php endif; ?>><?php echo e($classroom->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <?php $__errorArgs = ['classroom_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <hr class="mx-auto" style="width:90%;opacity: 1;border:3px solid #044c71;border:3px solid #044c71">

                <div class="col-md-3 col-sm-12">
                    <div class="form-group">
                        <label for="week">الاٍسبوع</label>
                        <input readonly id="week" type="text" class="form-control" value="<?php echo e($week->week_index); ?>" >
                    </div>
                </div>

                <div class="col-md-9 col-sm-12">
                    <div class="form-group">
                        <label for="week_date">التاريخ</label>
                        <input readonly id="week_date" type="text" class="form-control" value="<?php echo \Carbon\Carbon::parse($week->start_date)->translatedFormat("l Y-m-d")."   -   ".\Carbon\Carbon::parse($week->end_date)->translatedFormat("l Y-m-d"); ?>" >
                    </div>
                </div>

                <div class="mx-auto" style="width:90%;background: #4eaf52;color:#044c71;text-align:center;vertical_aline:middle">
                    <h3 style="height:70px;padding-top:30px"> بنود المتابعة </h3>
                </div>

                <div class="col-sm-12 pt-5"></div>

                <div class="col-md-12 col-sm-12 review">
                    <div class="form-group row">
                        <label class="col-lg-3  col-sm-12" for="tasks">الواجبات المرفوعة</label>
                        <input id="tasks" type="number" min="0" style="width: 90%" class="form-control col-lg-7  col-sm-12" wire:model="tasks">
                    </div>
                </div>

                <div class="col-md-12 col-sm-12 review">
                    <div class="form-group row">
                        <label class="col-lg-3 col-sm-12" for="lessons">الدروس المحضرة</label>
                        <input id="lessons" type="number" min="0" style="width: 90%" class="form-control col-lg-7 col-sm-12" wire:model="lessons">
                    </div>
                </div>

                <div class="col-md-12 col-sm-12 review">
                    <div class="form-group row">
                        <label class="col-lg-3 col-sm-12" for="weekly_plan">الخطة الأسبوعية</label>
                        <input id="weekly_plan" type="number" min="0" style="width: 90%" class="form-control col-lg-7 col-sm-12" wire:model="weekly_plan">
                    </div>
                </div>

                <div class="col-md-12 col-sm-12 review">
                    <div class="form-group row">
                        <label class="col-lg-3 col-sm-12" for="result">الأجمالى</label>
                        <input readonly id="result"  type="text"  style="width: 90%" class="form-control col-lg-7 col-sm-12" wire:model="result">
                    </div>
                </div>



                

                <div class="mx-auto" style="width:90%;background: #4eaf52;color:#044c71;text-align:center;vertical_aline:middle">
                    <h3 style="height:70px;padding-top:30px"> الملاحظات </h3>
                </div>
                <div class="col-sm-12 pt-5"></div>

                <div class="col-md-12 col-sm-12">
                    <div class="form-group">
                        <label for="notes">فى حالة وجود مشاكل تواجهك  أثناء الأسبوع يرجى إضافتها</label>
                        <textarea name="notes" id="notes" placeholder="اكتب ملاحظاتك هنا" class="form-control" wire:model.lazy="notes" cols="30" rows="6">
                            <?php echo e($notes); ?>

                        </textarea>
                    </div>
                </div>

                <div class="col-md-8 col-sm-8 m-auto">
                <?php if($method != "add"): ?>
                    <button type="submit" class="btn btn-primary d-block w-100">حفظ التغييرات</button>
                <?php else: ?>
                    <button type="submit" class="btn btn-primary d-block w-100">إرسال</button>
                <?php endif; ?>
                </div>
            </div>
        </form>
    </div>
</div>

<?php /**PATH D:\xampp\htdocs\elnajat_edu\resources\views/livewire/review/review.blade.php ENDPATH**/ ?>