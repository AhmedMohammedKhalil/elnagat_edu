<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row page-titles mx-0" style="height: 200px">
            <div class="col-sm-12">
                <div class="welcome-text text-center">
                    <h4>تعديل بيانات الصف الدراسي </h4>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6 col-sm-12 m-auto">
                <div class="card">
                    <div class="card-body">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.classroom', ['classroomId' => $classroom_id,'method' => 'edit','classroom_id' => $classroom_id])->html();
} elseif ($_instance->childHasBeenRendered('GJH3HYf')) {
    $componentId = $_instance->getRenderedChildComponentId('GJH3HYf');
    $componentTag = $_instance->getRenderedChildComponentTagName('GJH3HYf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GJH3HYf');
} else {
    $response = \Livewire\Livewire::mount('admin.classroom', ['classroomId' => $classroom_id,'method' => 'edit','classroom_id' => $classroom_id]);
    $html = $response->html();
    $_instance->logRenderedChild('GJH3HYf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\elnajat_edu\resources\views/admin/classroom_edit.blade.php ENDPATH**/ ?>