<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row page-titles mx-0" style="height: 200px">
            <div class="col-sm-12">
                <div class="welcome-text text-center">
                    <h4>تعديل بيانات المتابعة </h4>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12 col-sm-12 m-auto">
                <div class="card">
                    <div class="card-body">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('review.review', ['weekId' => '0','reviewId' => $review_id,'method' => 'edit','week_id' => '0','review_id' => $review_id])->html();
} elseif ($_instance->childHasBeenRendered('J5pqoBh')) {
    $componentId = $_instance->getRenderedChildComponentId('J5pqoBh');
    $componentTag = $_instance->getRenderedChildComponentTagName('J5pqoBh');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('J5pqoBh');
} else {
    $response = \Livewire\Livewire::mount('review.review', ['weekId' => '0','reviewId' => $review_id,'method' => 'edit','week_id' => '0','review_id' => $review_id]);
    $html = $response->html();
    $_instance->logRenderedChild('J5pqoBh', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\elnajat_edu\resources\views/reviews/edit.blade.php ENDPATH**/ ?>