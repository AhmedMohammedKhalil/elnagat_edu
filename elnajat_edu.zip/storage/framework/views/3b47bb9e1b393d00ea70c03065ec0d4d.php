<div style="">
    <div class="login-form">
        <form wire:submit.prevent='<?php echo e($method); ?>'>
            <?php if(session()->has('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
                <div class="form-group">
                    <label for="name">الإسم</label>
                    <input type="text" wire:model.lazy='name' id="name" class="form-control" placeholder="الإسم">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="owner">رئيس القسم</label>
                    <input type="text" wire:model.lazy='owner' id="owner" class="form-control" placeholder="رئيس القسم">
                    <?php $__errorArgs = ['owner'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <?php if($method != "add"): ?>
                    <button type="submit" class="btn btn-primary d-block m-auto">حفظ التغييرات</button>
                <?php else: ?>
                    <button type="submit" class="btn btn-primary d-block m-auto">إضافة</button>
                <?php endif; ?>
        </form>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\elnajat_edu\resources\views/livewire/department/department.blade.php ENDPATH**/ ?>