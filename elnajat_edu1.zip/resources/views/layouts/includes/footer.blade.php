

<div class="footer">
    <div class="copyright">
        <p style="color:#044c71 !important">جميع الحقوق محفوظة للإدارة العامة لمدارس النجاة - الفريق التشغيلى للمدارس © 2024 </p>
    </div>
</div>
