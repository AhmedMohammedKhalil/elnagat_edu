<div class="dlabnav" style="top:7rem">
    <div class="dlabnav-scroll">
        <ul class="metismenu" id="menu">
            <li class="nav-label first">القائمة الرئيسية</li>

            <?php if(auth()->user()->role != 'sub_admin'): ?>
            <li><a class="ai-icon" href="<?php echo e(route('dashboard')); ?>" aria-expanded="false">
                    <i class="la la-home"></i>
                    <span class="nav-text">لوحة التحكم</span>
                </a>
            </li>
            <li><a class="ai-icon" href="<?php echo e(route('sub_admins.index')); ?>" aria-expanded="false">
                    <i class="la la-user"></i>
                    <span class="nav-text">المدراء المساعدين</span>
                </a>
            </li>
            <li><a class="ai-icon" href="<?php echo e(route('schools.index')); ?>" aria-expanded="false">
                    <i class="la la-school"></i>
                    <span class="nav-text">المدارس</span>
                </a>
            </li>
            <li><a class="ai-icon" href="<?php echo e(route('departments.index')); ?>" aria-expanded="false">
                    <i class="la la-building"></i>
                    <span class="nav-text">الأقسام</span>
                </a>
            </li>
            <li><a class="ai-icon" href="<?php echo e(route('teachers.index')); ?>" aria-expanded="false">
                    <i class="la la-users"></i>
                    <span class="nav-text">المعلمين</span>
                </a>
            </li>
            <?php if(auth()->user()->role == 'admin'): ?>
            <li><a class="ai-icon" href="<?php echo e(route('officials.index')); ?>" aria-expanded="false">
                    <i class="la la-users"></i>
                    <span class="nav-text">فريق التشغيل</span>
                </a>
            </li>
            <?php endif; ?>
            <?php else: ?>
            <li><a class="ai-icon" href="<?php echo e(route('')); ?>" aria-expanded="false">
                    <i class="la la-users"></i>
                    <span class="nav-text">التقييمات</span>
                </a>
            </li>
            <?php endif; ?>
            <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">
                    <i class="la la-id-card-alt"></i>
                    <span class="nav-text">البيانات الشخصية</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="<?php echo e(route('profile')); ?>">البروفايل</a></li>
                    <li><a href="<?php echo e(route('settings')); ?>">تعديل البروفايل</a></li>
                    <li><a href="<?php echo e(route('changePassword')); ?>">تغيير كلمة السر</a></li>
                </ul>
            </li>
            <li><a class="ai-icon" href="<?php echo e(route('logout')); ?>" aria-expanded="false">
                    <i class="la la-sign-out-alt"></i>
                    <span class="nav-text">خروج</span>
                </a>
            </li>

        </ul>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\elnajat_edu\resources\views/layouts/includes/sidebar.blade.php ENDPATH**/ ?>