<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">

        <div class="row page-titles mx-0" style="height: 200px">
            <div class="col-sm-12">
                <div class="welcome-text text-center">
                    <h4>الأقسام</h4>
                </div>
            </div>
        </div>

        <div class="row">
            <?php if(count($schools) > 0): ?>
                <div class="col-lg-12">
                    <ul class="nav nav-pills mb-3">
                        <li class="nav-item"><a href="#list-view" data-bs-toggle="tab" class="nav-link me-1 show active">عرض الأقسام</a></li>
                        <li class="nav-item"><a href="#add-department" data-bs-toggle="tab" class="nav-link">إضافة قسم جديد</a></li>
                    </ul>
                </div>
                <div class="col-lg-12">
                    <div class="row tab-content">
                        <div id="list-view" class="tab-pane fade active show col-lg-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">جميع الأقسام</h4>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="example5" class="display text-nowrap text-center" style="min-width: 845px">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>الإسم</th>
                                                    <th>رئيس القسم</th>
                                                    <th>المدرسة</th>
                                                    <th>الإعدادات</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $depratments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td><?php echo e($department->name); ?></td>
                                                        <td><?php echo e($department->owner); ?></td>
                                                        <td><?php echo e($department->school->name); ?></td>
                                                        <td>
                                                            <a href="<?php echo e(route('depratments.edit',['id' => $department->id])); ?>" title="تعديل" class="btn btn-xs sharp btn-primary"><i class="fa fa-pencil"></i></a>
                                                            <?php if(count($department->teachers) == 0): ?>
                                                                <form style="display:inline-block" action="<?php echo e(route('depratments.destroy',['id'=>$department->id])); ?>" method="post">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('delete'); ?>
                                                                    <button class="btn btn-xs sharp btn-danger" type="submit" title="حذف" >
                                                                        <i class='fa fa-trash'></i>
                                                                    </button>
                                                                </form>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(count($depratments) == 0): ?>
                                                    <tr>
                                                        <td colspan="5">
                                                            <h4 class="text-center">لا يوجد أقسام </h4>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="add-department" class="tab-pane fade col-lg-12 row">
                            <div class="col-lg-6 col-sm-12 m-auto">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="card-title">أضف قسم جديد</h4>
                                    </div>
                                    <div class="card-body">
                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('department.department', ['departmentId' => '0','method' => 'add','department_id' => '0'])->html();
} elseif ($_instance->childHasBeenRendered('xodCXzK')) {
    $componentId = $_instance->getRenderedChildComponentId('xodCXzK');
    $componentTag = $_instance->getRenderedChildComponentTagName('xodCXzK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('xodCXzK');
} else {
    $response = \Livewire\Livewire::mount('department.department', ['departmentId' => '0','method' => 'add','department_id' => '0']);
    $html = $response->html();
    $_instance->logRenderedChild('xodCXzK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <?php else: ?>
                <div class="col-12">
                    <h2 class="text-center">لا يوجد  مدارس لابد من إضافة المدارس اولاً</h2>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\elnajat_edu\resources\views/departments/index.blade.php ENDPATH**/ ?>