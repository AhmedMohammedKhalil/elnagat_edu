
                <form wire:submit.prevent='login' class="row">
                    <?php if(session()->has('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="form-group col-10 m-auto">
                        <label class="form-label" for="email">البريد الإلكترونى</label>
                        <input type="email" wire:model.lazy='email' id="email" class="form-control" placeholder="البريد الإلكترونى">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-4 position-relative form-group col-10 m-auto">
                        <label class="form-label" for="dlabPassword">كلمة المرور</label>
                        <input type="password" wire:model.lazy='password' id="dlabPassword" class="form-control" placeholder="كلمة المرور">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-10 text-center mx-auto mb-4" style="margin-top: 5px">
                        <button type="submit" class="btn btn-primary w-100">تسجيل الدخول</button>
                    </div>
                </form>
<?php /**PATH D:\xampp\htdocs\elnajat_edu\resources\views/livewire/user/login.blade.php ENDPATH**/ ?>